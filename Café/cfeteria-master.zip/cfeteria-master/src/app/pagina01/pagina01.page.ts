import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina01',
  templateUrl: './pagina01.page.html',
  styleUrls: ['./pagina01.page.scss'],
})
export class Pagina01Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
